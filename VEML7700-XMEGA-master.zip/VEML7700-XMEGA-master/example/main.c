#define F_CPU 32000000UL
#include "VEML7700.h"
#include "clock.h"
#include "i2c.h"
#include "serialF0.h"
#include <math.h>
#include <avr/io.h>
#include <avr/interrupt.h>
#include <util/delay.h>
#include <stdio.h>
#include <stdlib.h>

#define TWI_BAUD(F_SYS, F_TWI)   ((F_SYS / (2 * F_TWI)) - 5)
#define BAUD_400K 400000UL

int main(void){
	float lux;
	init_clock();
	init_stream(F_CPU);
	sei();
	i2c_init(&TWIE, TWI_BAUD(F_CPU, BAUD_400K));
	PORTE.DIRSET    = PIN1_bm|PIN0_bm;           // SDA 0 SCL 1
	PORTE.PIN0CTRL  = PORT_OPC_WIREDANDPULL_gc;  // pullup SDA
	PORTE.PIN1CTRL  = PORT_OPC_WIREDANDPULL_gc;  // pullup SCL
	
	
	while(1){
		VEML7700_begin();
		getALSLux( &lux);
		printf("lux: %f\n",lux);
		_delay_ms(100);
		
	}
return 0;
}

